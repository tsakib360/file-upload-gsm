<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Subcategory;
use App\Models\Category;
use DB;


class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }
    public function category()
    {
        return view('admin.category');
    }
    public function managecategory()
    {
       
        $users = Category::all();
        return view('admin.managecategory',compact('users'));
    }
    public function subcategory()
    {
        $users = Category::all();
        return view('admin.subcategory',compact('users'));
      
    }
    public function managesubcategory()
    { 
        $users = Subcategory::all();
        return view('admin.managesubcategory',compact('users'));
    }
    public function upload()
   
    {
        $data = DB::table('categories')->get();
        return view('admin.upload')->with('data', $data);
       
    }
    public function user()
    {
        return view('admin.user');
    }
    public function download()
    {
        return view('admin.download');
    }
    public function categorydelete($id){
        $users=Category::find($id);
        $users->delete();
        return back();
    }
    public function subcategorydelete($id){
        $users=Subcategory::find($id);
        $users->delete();
        return back();
    }
    public function categoryedit($id){
        $users=Category::find($id);
       
        return view('admin.categoryedit',compact('users','id'));
    }
    public function subcategoryedit(){
        $users=Subcategory::join('categories', 'categories.id', '=', 'subcategories.category_id')
                            ->get(['subcategories.*', 'categories.categoryname']);
                            
                        
        return view('admin.subcategoryedit',compact('users'));
    }
    public function updatecategory(Request $request){
           
        $users=Category::find($request->id);   
        $users->categoryname=$request->get('categoryname');
       
       
        
        $users->save();
     

       
      return back();
   
    }
    public function updatesubcategory(Request $request){
           
        $users=Subcategory::find($request->id);   
        $users->subcategoryname=$request->get('subcategoryname');
       
       
        
        $users->save();
     

        $users = Subcategory::all();
        return view('admin.managecategory',compact('users'));
   
    }
}