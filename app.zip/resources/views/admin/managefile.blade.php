@extends('admin.index')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/addons/datatables.min.css" rel="stylesheet">
<!-- DataTables JS -->
<script src="js/addons/datatables.min.js" type="text/javascript"></script>

<!-- DataTables Select CSS -->
<link href="css/addons/datatables-select.min.css" rel="stylesheet">
<!-- DataTables Select JS -->
<script src="js/addons/datatables-select.min.js" type="text/javascript"></script>
    <title>Document</title>
</head>
<body>
<table id="dt-select" class="table table-striped table-bordered" cellspacing="0" width="100%">
<thead>
<tr>
<td>Id</td>
<td>Category</td>
<td>Subcategory</td>
<td>File Nmae</td>
<td>File Description</td>
<td>File Image</td>
<td>File </td>
<td>Amount </td>

<td>Action</td>
</tr>
</thead>
@foreach ($users as $user)
<tr>
<td>{{ $user->id }}</td>
<td>{{ $user->categoryname }}</td>
<td>{{ $user->subcategoryname }}</td>
<td>{{ $user->filename }}</td>
<td>{{ $user->filedescription }}</td>
<td><img width="30%" class="img-circle" src="{{ URL::asset('storage/images'.$user->fileimage) }}"></td>
<td>{{ $user->file }}</td>
<td>{{ $user->amount}}</td>






<td> <a class="btn btn-info" href = "">Edit</a>
<a class="btn btn-danger" href = >Delete</a></td>
</td>
</tr>
@endforeach
</table>
</body>
</html>
@endsection