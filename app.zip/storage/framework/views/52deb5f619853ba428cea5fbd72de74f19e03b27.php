
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
   
   
</head>
<body>
  
<div class="container">

    Welcome, <?php echo e(auth()->guard('admin')->user()->name); ?> <br>
    In the Admin Dashboard.....
</div>
   
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\fileupload\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>