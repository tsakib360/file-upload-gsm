
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/addons/datatables.min.css" rel="stylesheet">
<!-- DataTables JS -->
<script src="js/addons/datatables.min.js" type="text/javascript"></script>

<!-- DataTables Select CSS -->
<link href="css/addons/datatables-select.min.css" rel="stylesheet">
<!-- DataTables Select JS -->
<script src="js/addons/datatables-select.min.js" type="text/javascript"></script>
    <title>Document</title>
</head>
<body>
<table id="dt-select" class="table table-striped table-bordered" cellspacing="0" width="100%">
<thead>
<tr>
<td>Id</td>
<td>Category</td>
<td>Subcategory</td>
<td>File Nmae</td>
<td>File Description</td>
<td>File Image</td>
<td>File </td>
<td>Amount </td>

<td>Action</td>
</tr>
</thead>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($user->id); ?></td>
<td><?php echo e($user->categoryname); ?></td>
<td><?php echo e($user->subcategoryname); ?></td>
<td><?php echo e($user->filename); ?></td>
<td><?php echo e($user->filedescription); ?></td>
<td><img width="30%" class="img-circle" src="<?php echo e(URL::asset('storage/images'.$user->fileimage)); ?>"></td>
<td><?php echo e($user->file); ?></td>
<td><?php echo e($user->amount); ?></td>






<td> <a class="btn btn-info" href = "">Edit</a>
<a class="btn btn-danger" href = >Delete</a></td>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\fileupload\resources\views/admin/managefile.blade.php ENDPATH**/ ?>