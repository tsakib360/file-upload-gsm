<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="assets/css/styles.css" rel="stylesheet" />
</head>
<body>
<div class="container">
        <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id"  Value="" >
     
            <div class="row" style="margin-top: 100px;">
                <div class="col-md-6 col-md-offset-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3>Add subcategory</h3>
                        </div>
                        <div class="panel-body">
                        <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
                        <label>Category</label>
                         <select type="text" class="form-control" name="category_id"> 
                         <option  selected>Select category</option>
                         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <option  Value="<?php echo e($user->id); ?>"><?php echo e($user->categoryname); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                       
                         <label>Subcategory</label>
                        <div class="form-group">
                    
                               <input type="text" class="form-control" name="subcategoryname"Value="<?php echo e($user->subcategoryname); ?>">
                         </div>
                            
                    </div>
                    <button class="btn btn-primary " type="submit">Submit</button>
                </div>
            </div>
        </form>
    </div>
    
</body>
</html><?php /**PATH D:\laravel\fileupload\resources\views/admin/subcategoryedit.blade.php ENDPATH**/ ?>